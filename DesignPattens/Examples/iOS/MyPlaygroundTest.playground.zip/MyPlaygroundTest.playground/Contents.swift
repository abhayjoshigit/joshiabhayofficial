import UIKit

var greeting = "Hello, playground"

let scores = ["1", "2", "three", "four", "5"]

let mapped: [Int?] = scores.map { str in Int(str) }
// [1, 2, nil, nil, 5] - Two nil values as "three" and "four" are strings.
print(mapped)

let compactMapped: [Int] = scores.compactMap { str in Int(str) }
print(compactMapped)


//Stratergy patten

class Duck {
    var fb: IflyBehaviour
    var qb:IquackBehaviour
    var db:IdisplayBehaviour
    
    //init Duck Class
     init(quackBehavior Qb:IquackBehaviour, flyBehavior Fb:IflyBehaviour, displayBehavior Db:IdisplayBehaviour){
        
        self.db = Db
        self.qb = Qb
        self.fb = Fb
    }
    /*(
    func quack(){
        print("Duck Class:- Quack() ")
    }
    func display() {
        print("Duck Class:- display() ")
    }
    func fly() {
        print("Duck Class:- fly() ")
    }
    */
}
protocol IflyBehaviour{
    func fly()
}
protocol IquackBehaviour{
    func quack()
}
protocol IdisplayBehaviour{
    func display()
}

class displayAsText: IdisplayBehaviour{
    func display(){
        print("displayAsText Class:- display() ")
    }
}

class displayAsGraphically: IdisplayBehaviour{
    func display(){
        print("displayAsGraphically Class:- display() ")
    }
}

class simpleQuack: IquackBehaviour{
    func quack(){
        print("simpleQuack Class:- fly() ")
    }
}
class NoQuack: IquackBehaviour{
    func quack(){
        print("NoQuack Class:- fly() ")
    }
}
class simpleFly: IflyBehaviour{
    func fly(){
        print("simpleFly Class:- fly() ")
    }
}
class jetFly: IflyBehaviour{
    func fly(){
        print("jetFly Class:- fly() ")
    }
}
class wildDuck: Duck{
    /*
    override func display() {
        print("wildDuck Class:- fly() ")
    }
 */
}
/*
class cityDuck: Duck{
   
    override func display() {
        print("cityDuck Class:- fly() ")
    }

}
 */

//Creating Duck Object

let duck:Duck = Duck.init(quackBehavior: simpleQuack(), flyBehavior: simpleFly(), displayBehavior: displayAsText() as IdisplayBehaviour)

duck.db.display()
duck.fb.fly()

let cityDuck2:Duck  = Duck.init(quackBehavior: simpleQuack() , flyBehavior: jetFly(), displayBehavior: displayAsGraphically())

cityDuck2.db.display()
cityDuck2.fb.fly()
cityDuck2.qb.quack()

//Protocol Extension

protocol MyInterface {
    func myMethod() -> String
}

extension MyInterface {
    func myMethod() -> String {
        fatalError("Not Implemented")
    }
}

class MyConcreteClass: MyInterface {
    func myMethod() -> String {
        return "The output"
    }
}
MyConcreteClass().myMethod()

//protocol extensions
protocol colorChangable{
    func changeColor()
}
//Extension make method Option by adding default method
extension colorChangable{
    func changeColor() {
        print("Changing to While Color")
    }
}

class myButton: colorChangable{
   
}
   
struct myLabel: colorChangable{
    func changeColor() {
        print("Changing to While Color")
    }
}

class myView: colorChangable{
    func changeColor() {
        print("Changing to While Color")
    }
}

let mybtn = myButton()
mybtn.changeColor()

//Hashable and Equatable

struct Car:Equatable {
    let make: String
    let model: String
}

let bmw = Car(make: "BMW",model: "Series 4")
let benz = Car(make: "BENZ",model: "X Trip")
let benz2 = Car(make: "BENZ",model: "X Trip")

if(bmw == benz){
    print("Same Objects")
}
else{
    print("Different Models::")
}

//Hashable
struct UserAccount:Hashable{
    let accountIdentifier:String
}

struct Post:Hashable{
    let text:String
}

var dictionary = [
    UserAccount(accountIdentifier:"222"):[
    Post(text: "first")
    ]
]

//Reflection In Swift using Mirror API

struct Point{
    let x:CGFloat
    let y:CGFloat
}

let point = Point(x: 100, y: 50)
let reflection = Mirror(reflecting: point)

let children = reflection.children

for child in children{
    print("Child Label: \(String(describing: child.label) )")
    print("Child Value: \(child.value)")
}

//Protocol extension

/*
protocol protocolExtensionEx{
    func testExtenstion(inputStr: String) -> String
    func testimplementation(_: String, completion: (Int,Int) -> Int)
}

extension protocolExtensionEx{
    func testExtenstion(inputStr: String?) -> String  {
        guard let inputvalue:String? = inputStr else{
            return "UnKnown"
        }
    }
}
*/

// protocol associated type?
//https://www.hackingwithswift.com/example-code/language/what-is-a-protocol-associated-type

protocol ItemStoring {
    associatedtype DataType

    var items: [DataType] { get set}
  //  mutating func add(item: DataType)
}

extension ItemStoring {
    mutating func add(item: DataType) {
        items.append(item)
        print(item)
    }
}

struct NameDatabase: ItemStoring {
    var items = [String]()
}

var names = NameDatabase()
names.add(item: "James")
names.add(item: "Jess")


