/* -----------------
  Abhay Dated 21/04/2022
 
 Startergy design pattern implementation
 -----------------------------------
 */

import UIKit

var greeting = "Hello, playground"

protocol FlyBehaviour{
    func fly()
}

protocol LookBehaviour{
    func look()
}

protocol EatBehaviour{
    func eat()
}

class Duck{
    var iflyBehaviour: FlyBehaviour
    var ilookBehaviour: LookBehaviour
    var ieatBehaviour: EatBehaviour
    
    init(fb: FlyBehaviour, lb: LookBehaviour, eb: EatBehaviour)
    {
        self.iflyBehaviour = fb
        self.ilookBehaviour = lb
        self.ieatBehaviour = eb
        
    }
    
    func fly(){
        iflyBehaviour.fly()
    }
    
    func look(){
        ilookBehaviour.look()
    }
    func eat(){
        ieatBehaviour.eat()
    }
}

class Longdistance:FlyBehaviour{
    func fly() {
        print("City Duck doesn't fly longer")
    }
}

class shortDistance:FlyBehaviour {
    func fly() {
        print("City Duck doesn't fly longer")
    }
}

class cityFood:EatBehaviour {
    func eat() {
        print("City Duck eats Junk food")
    }
}

class villageFood:EatBehaviour {
    func eat() {
        print("Eat behavior villageFood")
    }
}

class Colorlook: LookBehaviour{
    func look(){
        print("LookBehaviour : Colorlook ")
    }
}
let cityFooder: EatBehaviour  = cityFood()
let distance: FlyBehaviour = Longdistance()
let color: LookBehaviour = Colorlook()

var cityDuck: Duck = Duck(fb: distance, lb: color, eb: cityFooder)

cityDuck.fly()
cityDuck.look()
cityDuck.eat()
