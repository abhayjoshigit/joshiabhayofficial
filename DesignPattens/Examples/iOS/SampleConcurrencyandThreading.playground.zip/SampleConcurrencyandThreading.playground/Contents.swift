import UIKit

var greeting = " Concurrency and Threading "

//main vs background

DispatchQueue.main.async {
    foo()
}
