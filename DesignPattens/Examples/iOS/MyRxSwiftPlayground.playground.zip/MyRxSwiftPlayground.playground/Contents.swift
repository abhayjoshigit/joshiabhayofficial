import UIKit
import RxSwift

/*
_ = Observable.from([1,2,3,4,5,6,7])

let observablejust = Observable.just(1)
let observableof = Observable.of([11,12,13,14,15])
let observableofArray = Observable.of([33,55,66,77,88])
let observablefrom = Observable.from([10,20,30,40,50,60])


observablefrom.subscribe{ event in
    print(event)
    
    if let element = event.element {
        print(element)
    }
}

observableofArray.subscribe{ event in
    print(event)
    
    if let elment = event.element{
        print(elment)
    }
}

observablefrom.subscribe(onNext: { element in
    print(element)
})
*/
let disposeBag = DisposeBag()

Observable.of("AA","BB","CC")
    .subscribe{
        print($0)
    }.disposed(by: disposeBag)
  
Observable<String>.create{ observer in
    observer.onNext("A")
    observer.onCompleted()
    observer.onNext("?")
    
    return Disposables.create()
}.subscribe(onNext: {print($0)}, onError: {print($0)}, onCompleted: {print("Completed")}, onDisposed: {print("onDisposed")}).disposed(by: disposeBag)

//Publish subjects
let subject = PublishSubject<String>()
subject.onNext("Issue 1")

subject.subscribe{ event in
    print(event)
}

subject.onNext("Issue 2")
subject.onNext("Issue 3")

subject.dispose()

subject.onCompleted()
subject.onNext("Issue 4")

//Behaviour subjects
//Publish subjects
let behaviorsubject = BehaviorSubject(value: "Initial Value")
behaviorsubject.onNext("Behaviour Issue 1")

behaviorsubject.subscribe{ event in
    print(event)
}

behaviorsubject.onNext("Behaviour last")

//Replay buffer
let replaySubject = ReplaySubject<String>.create(bufferSize: 2)
replaySubject.onNext("replaySubject Issue 1")
replaySubject.onNext("replaySubject Issue 2")
replaySubject.onNext("replaySubject Issue 3")
replaySubject.onNext("replaySubject Issue 4")

replaySubject.subscribe{
    print($0)
}

print("Subscription 2")

replaySubject.onNext("replaySubject Issue 5")
replaySubject.onNext("replaySubject Issue 6")

replaySubject.subscribe{
    print($0)
}

//Variable subject

//let variable = Variable("Initial Value")
let variable2 = Variable("Initial Value")
//variable2.value = "Hello World!!"
variable2.value.append("Variable Item --1 ")

variable2.asObservable().subscribe{
    print($0)
}

variable2.value.append("Variable Item --2 ")

