import UIKit

var str = "Hello, playground"

//https://leekahseng.medium.com/difference-between-get-and-get-set-which-one-to-choose-719fe9ec7704
//when should we use { get set } and { get } when declaring property requirements of a protocol.
protocol MyProtocol {
    var myVar1: String { get set }
    var myVar2: String { get }
}

struct MyStruct: MyProtocol {
    var myVar1 = ""
    var myVar2 = ""
}


var testStruct = MyStruct()
testStruct.myVar1 = "test var1"
testStruct.myVar2 = "test var2"

print(testStruct.myVar1) // "test var1"
print(testStruct.myVar2) // "test var2"

var testProtocol: MyProtocol = MyStruct()
testProtocol.myVar1 = "test var1" // No error
//testProtocol.myVar2 = "test var2" // error: cannot assign to property: 'myVar2' is a get-only property

//protocol extension from bobthedeveloper
protocol MathGenius{
    func calculateGPA()
}

extension MathGenius{
    func calculateGPA(){
        print("I'm Arya bhatta Maths genius ")
    }
}

struct testPOPext:MathGenius{
    func calculateGPA() {
        print("I'm testPOPext calculateGPA")
    }
}
testPOPext().calculateGPA()


protocol Identifiable {
    var id: String { get set }
    func identify()
}

extension Identifiable {
    func identify() {
        print("My ID is \(id).")
    }
}

protocol sleekable{
    var price:String{get}
}

struct Diamond:sleekable{
    var price:String = "Very High"
}

struct Ruby:sleekable{
    var price:String = " High"
}

struct Glass:sleekable{
    var price:String = "Cheap"
}

func stateThePrice<T: sleekable>(enterGem: T) {
    print(" I'm expensive, In fact i'm \(enterGem.price)")
}

//Design Delegate Receiver
protocol PassDataDelegate{
    func passData(data: String)
}

class FirstVC{
    var delegate: PassDataDelegate?
    
}

class SecondVC:PassDataDelegate{
    
    func passData(data: String ) {
        print("Somthing happend ####\(data) here #### ")
    }
}

let firstVC = FirstVC()
let secondVC = SecondVC()

firstVC.delegate = secondVC

firstVC.delegate?.passData(data: "ABHAY ")

//Purpose of Data Source: communicate backward from secondVC(delegate) to FirstVC(delegator)

//Delegate is CEO and secretary relationship

//Protocol design

protocol PassDataDelegateSource{
    func passData(data: String) -> String
}

//Design delegator: CEO /Sender
class FirstVCSource{
    var delegate: PassDataDelegateSource?
    
}

FirstVCSource().delegate?.passData(data: "Test from First VC")

//Design delegate: secretary
class SecondVCSource:PassDataDelegateSource{
    
    func passData(data: String ) -> String {
        print("Somthing happend ####\(data) here #### ")
        return "Returning Value from SecondVCSource"
    }
}

let firstVCSource = FirstVCSource()
let secondVCSource = SecondVCSource()

firstVCSource.delegate = secondVCSource

let msg = firstVCSource.delegate?.passData(data: "Test passing data source")
print("Message return: \(String(describing: msg ?? msg))")

//BOB Course 42: Lesson

class Passport{
    weak var human: Human?
    var citizenship: String
    
    init(citizenship: String) {
        self.citizenship = citizenship
        print("I'm citizen of \(citizenship)")
    }
    
    deinit {
        print("I'm gone in deinit")
    }
}

class Human{
    weak var passport: Passport?
    let name: String
    
    init(name: String) {
        self.name = name
        print("Human Name: \(name)")
    }
    
    deinit {
        print("I Human Name:\(name) gone")
    }
}

//Passport(citizenship: "Zambia")
var passprt = Passport(citizenship: "Kenya")

//Introduction to Automatic reference counting

var bob: Human? = Human(name:"Boddy")
var passpart: Passport?  = Passport(citizenship: "Republic of Korea")

bob?.passport = passpart
passpart?.human = bob

bob = nil
passpart = nil


//Delegate Retain cycle : Lesson 43
protocol sendDelegate: class{}

class SendingVC{
   weak var delegate:sendDelegate?
    
    deinit {
        print("Deinit in SendingVC")
    }
}

class RecevingVC:sendDelegate{
    lazy var sendingVC:SendingVC = {
        let vc = SendingVC()
        vc.delegate = self
        return vc
    }()
    
    deinit {
        print("RecevingVC deinit")
    }
}

var recevingVC: RecevingVC? = RecevingVC()
recevingVC?.sendingVC

recevingVC = nil


//Closure Retain cycle : Lesson 44

class BobClass{
    var bobClosure:(() -> ())?
    var name: String = "Bob"
    
    init(){
        bobClosure = {
            print("I'm in Init ")
        }
    }
    
}


//Chapter 54: Generic protocols
//Intro Associated Type

struct Genericstructs<T>{
    var property: T?
}

let explicit = Genericstructs<Bool>()
//T is Bool
let implicit = Genericstructs(property: "Abhay")
//T is String

//Design normal protocol
protocol NormalProtocol{
    var property: String {get set }
}

//Normal class
class Normalcls{
    var property: String = "Joshi"
}

//Chapter 55
protocol GenericProto{
    associatedtype myType
}

class somtest:GenericProto{
    typealias myType = String
}

struct somteststruct:GenericProto{
    typealias myType = Int
}

//Generic extension

extension GenericProto where myType == String{
    static func introduce(){
        print("I'm Abhay Joshiii")
    }
}

extension GenericProto{
     func introduceNon(){
        print("I'm Non static extension function ")
    }
}

extension GenericProto where Self  == somteststruct{
    static func introducestruct(){
        print("I'm Abhay Joshiii")
    }
}

let sontestclass = somtest()
sontestclass.introduceNon()
somtest.introduce()
somteststruct.introducestruct()

//Chapter : 56
//Problem : how to override pre-defined protocol?

protocol FamilyProtol{
    associatedtype familyType = Int
    var familymembers: [familyType] {get set}
}


//Enumaration

enum WeatherType {
    case sun
    case cloud
    case rain
    case wind(speed: Int)
    case snow
}

func getHaterStatus(weather: WeatherType) -> String? {
    switch weather {
    case .sun:
        return nil
    case .wind(let speed) where speed < 10:
        return "meh"
    case .cloud, .wind:
        return "dislike"
    case .rain, .snow:
        return "hate"
    }
}

getHaterStatus(weather: WeatherType.wind(speed: 5))

//Codable

struct User: Codable {
    var first_name: String
    var last_name: String
    var country: String
}

let jsonString = """
{
    "first_name": "John",
    "last_name":  "Doe",
    "country":    "United Kingdom"
}
"""


struct Stock: Codable {
    var warehouse: Int
    var retail: Int
}

struct Product: Codable {
    
    var id: Int
    var name: String
    var price: Int
    var types: [String]
    var stockInfo: Stock
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case price
        case types = "tags"
        case stockInfo = "stock"
    }
    
}

func fetchDataFromRemote() {
        let jsonString =
        """
        {
            "id": 1,
            "name": "chair",
            "price": 350,
            "tags": [
            "recliner",
            "foldable"
            ],
            "stock": {
                "warehouse": 300,
                "retail": 20
            }
        }
        """
        
    if let jsonData = jsonString.data(using: String.Encoding.utf8) as? Data {
               
               let decoder = JSONDecoder()
               
               let product = try! decoder.decode(Product.self, from: jsonData)
               
               print(product)
               print("************************")
               print(product.stockInfo)
               print(product.types)
               
           }
           
       }

struct Stocke: Codable {
    var warehouse: Int
    var retail: Int
}

struct Producte: Codable {
    
    var id: Int
    var name: String
    var price: Int
    var types: [String]
    var stockInfo: Stocke
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case price
        case types = "tags"
        case stockInfo = "stock"
    }
    
}

func exampleEncodeFunction() {
        
        let tableStock = Stocke.init(warehouse: 114, retail: 16)
        let table = Producte.init(id: 112, name: "Long Table", price: 450, types: ["Long", "Study", "Short"], stockInfo:tableStock )
        
        let encoder = JSONEncoder()
        
        let productData = try! encoder.encode(table.self)
        
        let productStr = String.init(data: productData, encoding: .utf8)
        print("String from Product data is \(productStr ?? "No data")")
        
    }

func getItem() -> String {
    let item: String = "abha"
 return item
}

let myItem = getItem()

//EMpty array
var val = [Int]()

let testarray = [68,66,78,4567,44]
val.append(contentsOf: testarray)
print("Array content \(val)")

let nilArray:[Int]? = nil
val = [Int]()
val.append(contentsOf: nilArray ?? [Int]())
print("nil array content \(val)")

