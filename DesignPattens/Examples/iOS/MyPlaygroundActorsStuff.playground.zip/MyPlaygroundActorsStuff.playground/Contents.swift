import UIKit

var greeting = "Hello, this is about Actors !!!!"

//Example  synchronizing without Actor
class User{
    let id:String
    let name:String
    
    init(id: String , name:String) {
        self.id = id
        self.name = name
    }
}

class UserStorage{
    private var dictionaryStore = [String:User]()
    private let queue = DispatchQueue(label: "user_save_queue")
    
    func get(_ id: String) -> User? {
        queue.sync{
            return self.dictionaryStore[id]
        }
    }
    
    func save(_ user:User){
        queue.sync{
            self.dictionaryStore[user.id] = user
        }
    }
}

//Example  synchronizing with Actor

actor ActorUserStorage{
    private var dictionaryStore = [String:User]()
   // private let queue = DispatchQueue(label: "user_save_queue")
    
    func get(_ id: String) -> User? {
        return dictionaryStore[id]
    
    }
    
    func save(_ user:User){
        dictionaryStore[user.id] = user
    
    }
    init(){}
}

let storage = ActorUserStorage()

Task {
    let user = User(id: "112233", name: "Stayakala")
    await storage.save(user)
    let get = await storage.get("112233")
    
    print(String(describing: get))
}


