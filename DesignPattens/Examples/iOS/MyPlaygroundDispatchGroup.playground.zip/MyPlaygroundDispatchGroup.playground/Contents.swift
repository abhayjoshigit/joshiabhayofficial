import UIKit

var greeting = "Hello, playground"

func getData(){
    let urls = [
      "https://api.google.com/1",
      "https://api.google.com/2",
       "https://api.google.com/3"
    ]
    
    let group = DispatchGroup()
    
    for url in urls {
        guard let url = URL(string: url) else{
            continue
        }
        
        group.enter() //We enter this group
        let task =  URLSession.shared.dataTask(with: url, completionHandler: { data, response , error in
            defer {
                group.leave() //leaving this gropu when completion handler is called
            }
            print("Completion handler is called:: Leaving ths group")
            guard let data = data else {
                return
            }
            print(data)
            
        })
        task.resume()
    }
    group.notify(queue: .main, execute: {
        print("completed fetching Url's ")
    })
}
        
